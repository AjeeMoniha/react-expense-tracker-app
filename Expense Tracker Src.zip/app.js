import React, { useState } from "react";
import './App.css';
import Expenses from "./components/expenses/Expenses";
import NewExpense from "./components/expenses/NewExpense";
const initial_expenses = [
  {
    id: 1,
    date: new Date(2022, 7, 15),
    title: "Car servicing",
    amount: 10000,
  },
  {
    id: 2,
    date: new Date(2022, 5, 15),
    title: "Schoold Fee",
    amount: 50000,
  },
  {
    id: 3,
    date: new Date(2021, 4, 10),
    title: "Shopping",
    amount: 50000,
  },
];
function App() {

  const [expenses, setExpenses] = useState(initial_expenses);
  const addExpenseHandler = (expense) => {
    //console.log("Inside app");
    //console.log(expenses);
    //expenses.push(expense);
    setExpenses((prevExpense) => {
      return [expense, ...prevExpense];
    });
  };

  return (
    <div className="App">
      <h1>EXPENSE TRACKER 💰</h1>
      <NewExpense onAddExpense={addExpenseHandler} />
      <Expenses expenses={expenses} />
    </div>
  );
}

export default App;
