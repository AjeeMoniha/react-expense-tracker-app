//import React,{useState} from "react"; //hook
import ExpenseDate from "./ExpenseDate";
import "./ExpenseItem.css";
import Card from './../ui/Card';

const ExpenseItem = (props) =>{

    const {expense} = props;

    return(
       <li>
        <Card className="expense-item">
            <ExpenseDate date={expense.date}/>
            <div className="expense-item__description">
               <h2>{expense.title}</h2>
            </div>
            <div className="expense-item__price">&#x20B9; {expense.amount}</div>
        </Card>
        </li>
    );
};
export default ExpenseItem;