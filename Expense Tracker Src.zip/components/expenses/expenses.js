import React, {useState} from "react";
import "./Expenses.css";
//import ExpenseItem from "./ExpenseItem";
import Card from './../ui/Card';
import ExpenseFilter from "./ExpenseFilter";
import ExpenseList from "./ExpenseList.js";
import ExpensesChart from "./ExpensesChart";

const Expenses = (props) => {
  const [filteredYear, setFilteredYear] = useState ("2020");
  const { expenses } = props;
  const filterChangeHandler =(selectedYear)=>{
    setFilteredYear(selectedYear); 
  };
  const filteredExpenses = expenses.filter((expense)=>{
    return expense.date.getFullYear().toString() === filteredYear;
  });

  return (
    <Card className="expenses">
      <ExpenseFilter selected = {filteredYear} onFilterChange={filterChangeHandler}/>
      <ExpensesChart expenses ={filteredExpenses}/>
      <ExpenseList expenses ={filteredExpenses}/>
    </Card>
  );
};
export default Expenses;