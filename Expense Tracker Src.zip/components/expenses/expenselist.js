import "./ExpenseList.css";
import React from "react";
import ExpenseItem from "./ExpenseItem";

const ExpenseList=(props) =>{
    if(props.expenses.length ===0){
        return<h2 className="expense-list__error">There is no expense</h2>;
    }
    return(
        <ul className="expense-list">
            {props.expenses.map((expense)=>{
                return<ExpenseItem key={expense.id} expense={expense}/>;
            })
            }
        </ul>
    );  
};

export default ExpenseList;